package br.com.prolog.dto;

import java.io.Serializable;

public class TabelaTotaisDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer codigo;
	private String tipoPausa;
	private Integer tempoRecomendado;
	private String horasNoturnas;
	private String tempoTotal;

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getTipoPausa() {
		return tipoPausa;
	}

	public void setTipoPausa(String tipoPausa) {
		this.tipoPausa = tipoPausa;
	}

	public Integer getTempoRecomendado() {
		return tempoRecomendado;
	}

	public void setTempoRecomendado(Integer tempoRecomendado) {
		this.tempoRecomendado = tempoRecomendado;
	}

	public String getTempoTotal() {
		return tempoTotal;
	}

	public void setTempoTotal(String tempoTotal) {
		this.tempoTotal = tempoTotal;
	}

	public void setHorasNoturnas(String horasNoturnas) {
		this.horasNoturnas = horasNoturnas;
	}

	public String getHorasNoturnas() {
		return horasNoturnas;
	}

}
