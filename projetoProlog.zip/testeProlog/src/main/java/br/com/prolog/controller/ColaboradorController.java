package br.com.prolog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.prolog.entity.Colaborador;
import br.com.prolog.repository.ColaboradorRepository;

@RestController
@RequestMapping("/colaboradores")
public class ColaboradorController {
	
	@Autowired
	ColaboradorRepository repository;
	
	@GetMapping
	public String hello() {
		return "Olá, mundo";
	}
	
	@GetMapping("/cadastrar")
	public String cadastrar() {
		return "/colaborador/cadastro";
	}

	@GetMapping("/listar")
	public List<Colaborador> listar() {
		System.out.println("teste colaborador");
		return repository.findAll();
	}
	
	@PostMapping("/salvar")
	public String salvar(Colaborador colaborador) {
		repository.save(colaborador);
		return "redirect:/colaborador/cadastrar";
	}

}
