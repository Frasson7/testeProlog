package br.com.prolog.dto;

import java.io.Serializable;
import java.util.Date;

public class MarcacaoDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long codigoVinculo;
	private String cpfColaborador;
	private String nomeColaborador;
	private String tipoPausa;
	private Integer tempoRecomendado;
	private Date dataMarcacaoInicio;
	private Date dataMarcacaoFim;
	private String tempoTotal;

	public Long getCodigoVinculo() {
		return codigoVinculo;
	}

	public void setCodigoVinculo(Long codigoVinculo) {
		this.codigoVinculo = codigoVinculo;
	}

	public String getCpfColaborador() {
		return cpfColaborador;
	}

	public void setCpfColaborador(String cpfColaborador) {
		this.cpfColaborador = cpfColaborador;
	}

	public String getNomeColaborador() {
		return nomeColaborador;
	}

	public void setNomeColaborador(String nomeColaborador) {
		this.nomeColaborador = nomeColaborador;
	}

	public String getTipoPausa() {
		return tipoPausa;
	}

	public void setTipoPausa(String tipoPausa) {
		this.tipoPausa = tipoPausa;
	}

	public Integer getTempoRecomendado() {
		return tempoRecomendado;
	}

	public void setTempoRecomendado(Integer tempoRecomendado) {
		this.tempoRecomendado = tempoRecomendado;
	}

	public Date getDataMarcacaoInicio() {
		return dataMarcacaoInicio;
	}

	public void setDataMarcacaoInicio(Date dataMarcacaoInicio) {
		this.dataMarcacaoInicio = dataMarcacaoInicio;
	}

	public Date getDataMarcacaofim() {
		return dataMarcacaoFim;
	}

	public void setDataMarcacaofim(Date dataMarcacaofim) {
		this.dataMarcacaoFim = dataMarcacaofim;
	}

	public String getTempoTotal() {
		return tempoTotal;
	}

	public void setTempoTotal(String tempoTotal) {
		this.tempoTotal = tempoTotal;
	}

	@SuppressWarnings("deprecation")
	public String getHorasNoturnas() {
		Date dataInicio = this.dataMarcacaoInicio;
		Date dataFim = this.dataMarcacaoFim;
		int dataTotal = 0;
		dataInicio.setHours(22);
		dataFim.setHours(05);
		
		if (this.dataMarcacaoInicio.after(dataInicio) && this.dataMarcacaoFim.before(dataFim)) {
			dataTotal = this.dataMarcacaoFim.getDate() - this.dataMarcacaoInicio.getDate();
		}
		if (this.dataMarcacaoInicio.before(dataInicio) && this.dataMarcacaoFim.before(dataFim)) {
			dataTotal = this.dataMarcacaoFim.getDate() - dataInicio.getDate();
		}
		if (this.dataMarcacaoInicio.before(dataInicio) && this.dataMarcacaoFim.after(dataFim)) {
			dataTotal = dataFim.getDate() - dataInicio.getDate();
		}
		if (this.dataMarcacaoInicio.after(dataInicio) && this.dataMarcacaoFim.after(dataFim)) {
			dataTotal = dataFim.getDate() - this.dataMarcacaoInicio.getDate();
		}

		return Integer.toString(dataTotal);
	}

	public void setHorasNoturnas(String horasNoturnas) {
	}

	public Date getDataMarcacaoFim() {
		return dataMarcacaoFim;
	}

	public void setDataMarcacaoFim(Date dataMarcacaoFim) {
		this.dataMarcacaoFim = dataMarcacaoFim;
	}

}
