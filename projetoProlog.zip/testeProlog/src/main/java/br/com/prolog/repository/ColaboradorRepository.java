package br.com.prolog.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.prolog.entity.Colaborador;

@Repository
public interface ColaboradorRepository extends JpaRepository<Colaborador, String>{
	

}
