package br.com.prolog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.prolog.dto.MarcacaoDto;
import br.com.prolog.dto.TabelaTotaisDto;
import br.com.prolog.entity.Marcacao;
import br.com.prolog.repository.MarcacaoRepository;
import br.com.prolog.service.MarcacaoService;

@RestController
@RequestMapping("/marcacaos")
public class MarcacaoController {

	@Autowired
	MarcacaoRepository marcacaoRepository;

	@Autowired
	MarcacaoService marcacaoService;

	@GetMapping("/listar")
	public List<Marcacao> listar() {
		return marcacaoRepository.findAll();
	}

	@GetMapping("/marcacao")
	public List<MarcacaoDto> findMarcacao() {
		return marcacaoService.findMarcacao();
	}

	@GetMapping("/marcacaoRefeicao")
	public List<TabelaTotaisDto> findMarcacaoRefeicao() {
		return marcacaoService.findMarcacaoRefeicao();
	}

	@GetMapping("/marcacaoJornada")
	public List<TabelaTotaisDto> findMarcacaoJornada() {
		return marcacaoService.findMarcacaoJornada();
	}

	@GetMapping("/marcacaoEspera")
	public List<TabelaTotaisDto> findMarcacaoEspera() {
		return marcacaoService.findMarcacaoEspera();
	}

	@GetMapping("/marcacaoDescanso")
	public List<TabelaTotaisDto> findMarcacaoDescanso() {
		return marcacaoService.findMarcacaoDescanso();
	}

	@GetMapping("/tabelaTotais")
	public List<TabelaTotaisDto> findMarcacaoTotal() {
		return marcacaoService.findMarcacaoTotal();
	}

}
