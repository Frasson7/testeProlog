package br.com.prolog.entity;


import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "marcacao")
public class Marcacao implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "codigo")
	private Long codigo;
	
	@Column(name = "data_hora_marcacao")
	@Temporal(TemporalType.DATE)
	private Date data;
	
	@Column(name = "tipo_marcacao")
	private String tipo_marcacao;
	
	@ManyToOne
	@JoinColumn(name = "cod_tipo_marcacao")
	private TipoMarcacao tipoMarcacao;
	
	@ManyToOne
	@JoinColumn(name = "cpf_colaborador")
	private Colaborador colaborador;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public TipoMarcacao getTipoMarcacao() {
		return tipoMarcacao;
	}

	public void setTipoMarcacao(TipoMarcacao tipoMarcacao) {
		this.tipoMarcacao = tipoMarcacao;
	}

	public Colaborador getColaborador() {
		return colaborador;
	}

	public void setColaborador(Colaborador colaborador) {
		this.colaborador = colaborador;
	}

	public String getTipo_marcacao() {
		return tipo_marcacao;
	}

	public void setTipo_marcacao(String tipo_marcacao) {
		this.tipo_marcacao = tipo_marcacao;
	}

}
