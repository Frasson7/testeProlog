package br.com.prolog.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.prolog.entity.Marcacao;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface MarcacaoRepository extends JpaRepository<Marcacao, Long> {

}
