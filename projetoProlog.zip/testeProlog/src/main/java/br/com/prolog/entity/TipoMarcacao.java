package br.com.prolog.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "marcacao_tipo")
public class TipoMarcacao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "codigo")
	private Long codigo;
	
	
	@Column(name = "nome")
	private String nome;
	
	@Column(name = "tempo_recomendado_minutos")
	private Integer minutos;

	private TipoMarcacao(Long codigo, String nome, Integer minutos) {
		this.codigo = codigo;
		this.nome = nome;
		this.minutos = minutos;
	}

	private TipoMarcacao() {

	}

	public Integer getMinutos() {
		return minutos;
	}

	public void setMinutos(Integer minutos) {
		this.minutos = minutos;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
