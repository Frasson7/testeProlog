package br.com.prolog.controller;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.prolog.service.RelatorioService;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/relatorios")
public class RelatorioController {

	@Autowired
	private RelatorioService serviceRelatorio;

	@GetMapping("/relatorio")
	public ResponseEntity<String> downloadRelatorio(HttpServletRequest request) throws Exception {
		System.out.println("teste relatório");
		byte[] pdf = serviceRelatorio.gerarRelatorio("relatorio-marcacao", request.getServletContext());

		String base64pdf = "data:application/pdf;base64," + Base64.encodeBase64String(pdf);

		return new ResponseEntity<String>(base64pdf, HttpStatus.OK);
	}

}
