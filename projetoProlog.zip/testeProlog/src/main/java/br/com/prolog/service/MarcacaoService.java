package br.com.prolog.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Service;

import br.com.prolog.dto.MarcacaoDto;
import br.com.prolog.dto.TabelaTotaisDto;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Service
public class MarcacaoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@PersistenceContext
	private EntityManager em;

	public List<MarcacaoDto> findMarcacao() {
		Query query = em.createNativeQuery("SELECT\r\n" + "    marcacaoVinculo.codigo AS codigoVinculo,\r\n"
				+ "    colaborador.cpf AS cpfColaborador,\r\n" + "    colaborador.nome AS nomeColaborador,\r\n"
				+ "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(inicio.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaoInicio,\r\n"
				+ "   	to_char(fim.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaofim,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	group by codigoVinculo, cpfColaborador, nomeColaborador, tipoPausa, tempoRecomendado, dataMarcacaoInicio, dataMarcacaofim\r\n"
				+ "	order by codigoVinculo");

		@SuppressWarnings(value = { "unchecked" })
		List<MarcacaoDto> retorno = query.getResultList();
		em.close();
		return retorno;
	}

	public List<TabelaTotaisDto> findMarcacaoRefeicao() {
		Query query = em.createNativeQuery("SELECT\r\n" + "    colaborador.cpf AS cpfColaborador,\r\n"
				+ "    colaborador.nome AS nomeColaborador,\r\n" + "	marcacaoTipo.codigo AS codigoTipo,\r\n"
				+ "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(inicio.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaoInicio,\r\n"
				+ "   	to_char(fim.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaofim,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 28\r\n"
				+ "	group by codigoTipo, tipoPausa, tempoRecomendado, cpfColaborador, tipoPausa, dataMarcacaoInicio, dataMarcacaofim\r\n"
				+ "	order by codigoTipo");

		@SuppressWarnings(value = { "unchecked" })
		List<TabelaTotaisDto> retorno = query.getResultList();
		em.close();
		return retorno;
	}

	public List<TabelaTotaisDto> findMarcacaoJornada() {
		Query query = em.createNativeQuery("SELECT\r\n" + "    colaborador.cpf AS cpfColaborador,\r\n"
				+ "    colaborador.nome AS nomeColaborador,\r\n" + "	marcacaoTipo.codigo AS codigoTipo,\r\n"
				+ "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(inicio.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaoInicio,\r\n"
				+ "   	to_char(fim.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaofim,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 29\r\n"
				+ "	group by codigoTipo, tipoPausa, tempoRecomendado, cpfColaborador, tipoPausa, dataMarcacaoInicio, dataMarcacaofim\r\n"
				+ "	order by codigoTipo");

		@SuppressWarnings(value = { "unchecked" })
		List<TabelaTotaisDto> retorno = query.getResultList();
		em.close();
		return retorno;
	}

	public List<TabelaTotaisDto> findMarcacaoEspera() {
		Query query = em.createNativeQuery("SELECT\r\n" + "    colaborador.cpf AS cpfColaborador,\r\n"
				+ "    colaborador.nome AS nomeColaborador,\r\n" + "	marcacaoTipo.codigo AS codigoTipo,\r\n"
				+ "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(inicio.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaoInicio,\r\n"
				+ "   	to_char(fim.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaofim,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 30\r\n"
				+ "	group by codigoTipo, tipoPausa, tempoRecomendado, cpfColaborador, tipoPausa, dataMarcacaoInicio, dataMarcacaofim\r\n"
				+ "	order by codigoTipo");

		@SuppressWarnings(value = { "unchecked" })
		List<TabelaTotaisDto> retorno = query.getResultList();
		em.close();
		return retorno;
	}

	public List<TabelaTotaisDto> findMarcacaoDescanso() {
		Query query = em.createNativeQuery("SELECT\r\n" + "    colaborador.cpf AS cpfColaborador,\r\n"
				+ "    colaborador.nome AS nomeColaborador,\r\n" + "	marcacaoTipo.codigo AS codigoTipo,\r\n"
				+ "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(inicio.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaoInicio,\r\n"
				+ "   	to_char(fim.data_hora_marcacao, 'DD/MM/YYYY HH24:MI:SS') AS dataMarcacaofim,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 56\r\n"
				+ "	group by codigoTipo, tipoPausa, tempoRecomendado, cpfColaborador, tipoPausa, dataMarcacaoInicio, dataMarcacaofim\r\n"
				+ "	order by codigoTipo");

		@SuppressWarnings(value = { "unchecked" })
		List<TabelaTotaisDto> retorno = query.getResultList();
		em.close();
		return retorno;
	}

	public List<TabelaTotaisDto> findMarcacaoTotal() {
		Query query = em.createNativeQuery("SELECT\r\n" + "    1 AS codigo1,\r\n"
				+ "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 28\r\n" + "	group by codigo1, tipoPausa, tempoRecomendado\r\n"
				+ "union\r\n" + "SELECT\r\n" + "    2 AS codigo1,\r\n" + "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 29\r\n" + "	group by codigo1, tipoPausa, tempoRecomendado\r\n"
				+ "union\r\n" + "SELECT\r\n" + "    3 AS codigo1,\r\n" + "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 30\r\n" + "	group by codigo1, tipoPausa, tempoRecomendado\r\n"
				+ "union\r\n" + "SELECT\r\n" + "    2 AS codigo1,\r\n" + "    marcacaoTipo.nome AS tipoPausa,\r\n"
				+ "    marcacaoTipo.tempo_recomendado_minutos AS tempoRecomendado,\r\n"
				+ "	to_char(sum(fim.data_hora_marcacao - inicio.data_hora_marcacao), 'HH24:MI:SS') AS tempoTotal\r\n"
				+ "from marcacao_vinculo_inicio_fim marcacaoVinculo\r\n"
				+ "    LEFT JOIN marcacao inicio ON marcacaoVinculo.cod_marcacao_inicio = inicio.codigo\r\n"
				+ "    LEFT JOIN marcacao fim ON marcacaoVinculo.cod_marcacao_fim = fim.codigo\r\n"
				+ "    LEFT JOIN marcacao_tipo marcacaoTipo ON inicio.cod_tipo_marcacao = marcacaoTipo.codigo\r\n"
				+ "    LEFT JOIN colaborador colaborador ON inicio.cpf_colaborador = colaborador.cpf OR fim.cpf_colaborador = colaborador.cpf\r\n"
				+ "WHERE inicio.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "    AND fim.data_hora_marcacao BETWEEN TO_DATE('01/03/2019', 'DD/MM/YYYY') AND TO_DATE('10/03/2019', 'DD/MM/YYYY')\r\n"
				+ "	AND marcacaoTipo.codigo = 56\r\n" + "	group by codigo1, tipoPausa, tempoRecomendado");

		@SuppressWarnings(value = { "unchecked" })
		List<TabelaTotaisDto> retorno = query.getResultList();
		em.close();
		return retorno;

	}

	public String getHorasNoturnas() {
		findMarcacaoRefeicao();
		return null;
	}
}