package br.com.prolog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestePrologApplicationTests {

	@Test
	void contextLoads() {
	}

}
